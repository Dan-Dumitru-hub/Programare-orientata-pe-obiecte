/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author tipa
 */
public class Pasager {

    String nume;
    int varsta;
    String tip_bilet;//business,economic,premium //
    boolean imbarcare_prioritara;
    boolean nevoi_speciale;

    String nume_grup;

    public Pasager() {

        this.nume = new String();

        this.tip_bilet = new String();

        this.nume_grup = new String();

    }

    int prioritate(Pasager[][] p, int n, int nr1) {
        int i, prioritate = 0;
        int j;
        char c = p[nr1][0].nume_grup.charAt(0);
        if (c =='f') {
            prioritate += 10;
        }
        if (c == 'g') {
            prioritate += 5;
        }

        for (j = 0; j < n; j++) {
            if (p[nr1][j].imbarcare_prioritara) {
                prioritate += 30;
            }

            if (p[nr1][j].nevoi_speciale) {
                prioritate += 100;
            }

            if ("b".equals(p[nr1][j].tip_bilet)) {
                prioritate += 35;
            }
            if ("p".equals(p[nr1][j].tip_bilet)) {
                prioritate += 20;
            }

            if (p[nr1][j].varsta < 2 && p[nr1][j].varsta>=0) {
               prioritate += 20;
            }
            if (p[nr1][j].varsta <= 5 && p[nr1][j].varsta > 2) {
                prioritate += 10;
            }

            if (p[nr1][j].varsta <= 10 && p[nr1][j].varsta > 5) {
                prioritate += 5;
            }

            if (p[nr1][j].varsta >= 60) {
                prioritate += 15;
            }

        }
        return prioritate;
    }

}
