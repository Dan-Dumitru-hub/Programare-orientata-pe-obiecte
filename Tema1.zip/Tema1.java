/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

/**
 *
 * @author tipa
 */
public class Tema1 extends Pasager {

    String grup;

    int[] prioritati;
    // int prioritate;
    String[] grupuri;
    //PrintWriter scrie;
    FileWriter fr;

    public Tema1(int n, File x) throws FileNotFoundException, UnsupportedEncodingException, IOException {
        int i;
        this.grup = new String();
        this.prioritati = new int[n];
        this.grupuri = new String[n];
        //this.scrie=new PrintWriter("queue.out", "UTF-8");;
        this.fr = new FileWriter(x);
    }

    int nr_last() {
        int i, count = 0;
        for (i = 1; i < this.grupuri.length - 1; i++) {
            if (this.grupuri[i] != null) {
                count++;
            }
        }

        return count;
    }

    void max_heapify(Tema1 Arr, int i, int N) {
        int largest = i;

        int cv;
        String ceva = new String();
        int left = 2 * i;      //left child
        int right = 2 * i + 1; //right child

        if (left <= N && Arr.prioritati[left] > Arr.prioritati[i]) {
            largest = left;
        } else {
            largest = i;
        }

        if (right <= N && Arr.prioritati[right] > Arr.prioritati[largest]) {
            largest = right;
        }

        if (largest != i) {

            cv = Arr.prioritati[i];
            Arr.prioritati[i] = Arr.prioritati[largest];
            Arr.prioritati[largest] = cv;

            ceva = Arr.grupuri[i];
            Arr.grupuri[i] = Arr.grupuri[largest];
            Arr.grupuri[largest] = ceva;

            max_heapify(Arr, largest, N);

        }
    }

    void build_maxheap(Tema1 Arr, int N) {
//if (N%2!=0)
        for (int i = N / 2; i >= 1; i--) {
            max_heapify(Arr, i, N);
        }

    }

    void embark() {//scoate tatal arborelui
        int i;
        //System.out.print(" emb"+"\n");

        //for (i = 1; i < this.prioritati.length - 1; i++) {
           // this.prioritati[i] = this.prioritati[i + 1];
        //    this.grupuri[i] = this.grupuri[i + 1];
        //System.out.print(this.grupuri[i]+"\n");
        // }
        int n = this.nr_last();
        int cv = this.prioritati[1];
        this.prioritati[1] = this.prioritati[n];
        this.prioritati[n] = cv;

        String ceva = new String();
        ceva = this.grupuri[1];
        this.grupuri[1] = this.grupuri[n];
        this.grupuri[n] = ceva;

        this.grupuri[n] = null;
        this.prioritati[n] = -1;

        this.build_maxheap(this, this.prioritati.length - 1);
        //max_heapify(this, 1, this.grupuri.length);

    }
    /*
     void list() throws IOException {
     int n = this.nr_last();
     String newLine = System.getProperty("line.separator");
     if (this.prioritati[1] >= 0) {

     for (int i = 1; i < n; ++i) {
                
     //this.scrie.println(this.grupuri[i]);
     //this.scrie.println(" ");
                
     //this.fr.write(this.grupuri[i]);
     //this.fr.write(" ");
                
     System.out.print(this.grupuri[i]);
     System.out.print(" ");
     if (this.grupuri[2*i]!=null && (2*i)<=n){
     System.out.print(this.grupuri[2*i]);
     System.out.print(" ");}
     if (this.grupuri[2*i+1]!=null && (2*i+1) <=n){
     System.out.print(this.grupuri[2*i+1]);
     System.out.print(" ");}
                
                
     }
     //if (this.prioritati[n] >= 0) {
                
     // System.out.print(this.grupuri[n]);
                
     //this.scrie.println(this.grupuri[n]);
                
     //this.fr.write(this.grupuri[n]);
     //}

     }
     //this.scrie(System.getProperty("line.separator"));
     System.out.print("\n");
     //this.fr.write(newLine);
       

     }
     */

    void afis(int i) throws IOException {
        int n = this.nr_last();
        String newLine = System.getProperty("line.separator");
        //System.out.print(" ");
        
        this.fr.write(" ");
        //System.out.print(this.grupuri[i]);
this.fr.write(this.grupuri[i]);
        if ((2 * i) <= n && this.grupuri[2 * i] != null) {
            this.afis(2 * i);
        }

        if ((2 * i + 1) <= n && this.grupuri[2 * i + 1] != null) {
            this.afis(2 * i + 1);
        }
//this.fr.write(newLine);
    }

    void list() throws IOException {
String newLine = System.getProperty("line.separator");
        int n = this.nr_last();
        int i;

        if (this.prioritati[1] >= 0) {
            //System.out.print(this.grupuri[1]);
this.fr.write(this.grupuri[1]);
            if (this.prioritati[2] >= 0) {

                this.afis(2);
                if (this.prioritati[3] >= 0) {
                    this.afis(3);
                }
            }
//this.fr.write(newLine);
        }
    }

    void insert(Pasager p, int prioritate) {//baga pasager p in v
        //if (this.prioritati.length!=0)

        int n = this.prioritati.length;
        int n1 = p.varsta;
        //System.out.println("nr1="+n1+" bag pozx");
        this.grupuri[n1] = p.nume_grup;
        // this.list();
        this.prioritati[n1] = prioritate;
        this.build_maxheap(this, this.prioritati.length - 1);
    }

    public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException, IOException {
//System.out.println("asa");
        int i = 0, j = 0, k = 0, prioritate;
        
        
         File file1 = new File("queue.in");
    Scanner input = new Scanner(file1); 
 
    int count = 0;
    while (input.hasNext()) {
      String word  = input.next();
      if("list".equals(word))
      //System.out.println(word);
      count = count + 1;
    }
    //System.out.println("Word count: " + count);
        
        
String newLine = System.getProperty("line.separator");
        FileInputStream fis = new FileInputStream("queue.in");
        Scanner scanner = new Scanner(fis);

        int n = Integer.parseInt(scanner.next());
        int nr1 = 0, nr2 = 0, nr3 = 0;

//System.out.println(n);

        Pasager[][] A = new Pasager[n][n];
        Pasager B = new Pasager();
        Tema1[] v = new Tema1[n];

        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                A[i][j] = new Pasager();
                A[i][j].varsta = -1;
            }
        }
        
        
        
        
        
        

        // for (i = 0; i < n+1; i++) {
        //     v[i] = new Tema1(n);
        // }
        while (!scanner.hasNext("insert")) {
            nr1 = 0;
            nr2 = 0;
            String word = scanner.next();

            for (i = 1; i < n; i++) {
                if (word.equals(A[i][0].nume_grup)) {
                    nr1 = i;
                }
            }

            if (nr1 != 0) {
                for (k = 1; k < n; k++) {
                    if (A[nr1][k].varsta == -1) {
                        nr2 = k;
                        break;
                    }
                }

                A[nr1][nr2].nume_grup = word;
                A[nr1][nr2].nume = scanner.next();
                A[nr1][nr2].varsta = Integer.parseInt(scanner.next());
                A[nr1][nr2].tip_bilet = scanner.next();
                A[nr1][nr2].imbarcare_prioritara = Boolean.parseBoolean(scanner.next());
                A[nr1][nr2].nevoi_speciale = Boolean.parseBoolean(scanner.next());

            } else {
                nr3++;

                A[nr3][0].nume_grup = word;
                A[nr3][0].nume = scanner.next();
                A[nr3][0].varsta = Integer.parseInt(scanner.next());
                A[nr3][0].tip_bilet = scanner.next();
                A[nr3][0].imbarcare_prioritara = Boolean.parseBoolean(scanner.next());
                A[nr3][0].nevoi_speciale = Boolean.parseBoolean(scanner.next());

            }

        }

        File file = new File("queue.out");
        Tema1 w = new Tema1(nr3 + 1, file);

        for (i = 0; i < nr3 + 1; i++) {
            w.prioritati[i] = -1;
        }

        for (i = 1; i <= nr3; i++) {
            prioritate = A[i][0].prioritate(A, n, i);

       //System.out.print("\n");
            // System.out.print(A[i][0].nume_grup + "  ");
            //System.out.print(prioritate);
        }

        nr2 = 0;
        nr3 = 0;
        //PrintWriter a = new PrintWriter("queue.out", "UTF-8");


//System.out.println("cv");

String word6=new String();
        while (scanner.hasNext()) {
 word6 = scanner.next();
            if (word6.compareTo("insert")==0) {
                nr2++;
                //String word2 = scanner.next();

                String word3 = scanner.next();
                //System.out.print(word3);
                for (i = 0; i < n; i++) {
                    for (j = 0; j < n; j++) {
                        if (word3.equals(A[i][j].nume_grup)) {
                            nr1 = i;
                        }
                    }
                }

                //System.out.print(nr1);
                prioritate = A[nr1][0].prioritate(A, n, nr1);
                B.nume_grup = A[nr1][0].nume_grup;
               // if (w.prioritati[1]>=0)
                //nr2=w.nr_last();

                B.varsta = nr2 - nr3;
                //v[0].insert(A, prioritate, v, nr1);
                //System.out.print("insert");
                w.insert(B, prioritate);//ystem.out.print("\n");
                // w.list();
                // System.out.print("\n");
            }

            if (word6.compareTo("list")==0) {
                //String word4 = scanner.next();
count--;
                w.list();
                if(count!=0)
                w.fr.write(newLine);
               // if (scanner.next()!=null)
                
                
                
                //System.out.print("\n");
                // v[0].list(v);

            }
            if (word6.compareTo("embark")==0) {
                nr3++;
                //w.fr.write(newLine);
               // String word5 = scanner.next();
                w.embark();
                //w.fr.write(newLine);
                //System.out.print("\n");
                //w.list();
                //System.out.print("\n");
                //v[0].embark(v);
                //w.fr.write(newLine);
            }

        }

        scanner.close();
//this.scrie.close();
        w.fr.close();

    }
}

/**
 * @paramargs the command line arguments
 */
